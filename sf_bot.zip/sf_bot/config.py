TOKEN = '1668773334:AAHp2o3JxBvTlj5_Wn7v3ctXhFkkB0PpSIk'

keys = {
    'рубль': 'RUB',
    'евро': 'EUR',
    'доллар': 'USD',
}
